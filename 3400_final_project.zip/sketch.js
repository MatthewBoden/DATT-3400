let video;
let handpose;
let predictions = [];
let fingersUp = 0;
let fingersUpList = [];

const fingerNames = ["Thumb", "Index", "Middle", "Ring", "Pinky"];

function setup() {
  createCanvas(640, 480);

  // Webcam capture
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  console.log("Loading ML5 Handpose model...");
  handpose = ml5.handpose(video, modelReady);
  handpose.on("predict", results => {
    predictions = results;
  });
}

function modelReady() {
  console.log("Handpose model loaded!");
}

function draw() {
  background(0);

  // Mirror video
  push();
  translate(width, 0);
  scale(-1, 1);
  image(video, 0, 0, width, height);
  pop();

  // Draw hand and count fingers
  drawHand();

  // Display finger count
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text(`Fingers Up: ${fingersUp}`, width / 2, height - 50);

  // Display list of raised fingers
  textSize(24);
  let fingersText = fingersUpList.length > 0 ? fingersUpList.join(", ") : "None";
  text(`Raised: ${fingersText}`, width / 2, height - 20);
}

// Overlay hand tracking and count fingers
function drawHand() {
  if (predictions.length > 0) {
    let hand = predictions[0];
    let landmarks = hand.landmarks;

    let result = countFingers(landmarks);
    fingersUp = result.count;
    fingersUpList = result.names;

    for (let i = 0; i < landmarks.length; i++) {
      let [x, y] = landmarks[i];
      let mirroredX = width - x; // Align with video mirroring

      fill(0, 255, 0);
      noStroke();
      ellipse(mirroredX, y, 10, 10);
    }
  }
}

// Detect how many fingers are up and return their names
function countFingers(landmarks) {
  let count = 0;
  let raisedFingers = [];

  if (!landmarks || landmarks.length < 21) return { count: 0, names: [] };

  // Thumb: Compare tip (4) to knuckle (2)
  let thumbUp = landmarks[4][0] > landmarks[3][0]; // Adjust for mirroring
  if (thumbUp) {
    count++;
    raisedFingers.push("Thumb");
  }

  // Other fingers: Check if tip (8, 12, 16, 20) is above lower joint (6, 10, 14, 18)
  let fingers = [8, 12, 16, 20];
  let bases = [6, 10, 14, 18];

  for (let i = 0; i < fingers.length; i++) {
    if (landmarks[fingers[i]][1] < landmarks[bases[i]][1]) {
      count++;
      raisedFingers.push(fingerNames[i + 1]); // Skip thumb in names list
    }
  }

  return { count, names: raisedFingers };
}
